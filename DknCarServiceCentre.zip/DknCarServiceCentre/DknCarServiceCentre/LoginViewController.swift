//
//  LoginViewController.swift
//  DknCarServiceCentre
//
//  Created by h06 on 2017-03-28.
//  Copyright © 2017 daniel.karamjeet.nari.com. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    var URL_GET_TEAMS:String = "http://localhost/project/dkn/login_proc.php"
    var values :NSArray = []
    
    var rcv_username : String = ""
    var rcv_password : String = ""
    var rcv_is_block : String = ""
    var rcv_name     : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onSignIn(_ sender: Any) {
        let login : String = "Login"
        let username : String = "redeteus"
        let password : String = "sghs0721"
        
        let getString = "login=\(login)&username=\(username)&password=\(password)"
        URL_GET_TEAMS = URL_GET_TEAMS + "?" + getString
        
        //created NSURL
        let requestURL = NSURL(string: URL_GET_TEAMS)
        
        
        //creating NSMutableURLRequest
        let request = NSMutableURLRequest(url: requestURL! as URL)
        
        //setting the method to post
        request.httpMethod = "GET"
        
        //creating a task to send the post request
        let task = URLSession.shared.dataTask(with: request as URLRequest){
            data, response, error in
            
            //exiting if there is some error
            if error != nil{
                print("error is \(error)")
                return;
            }
            
            //parsing the response
            
            //converting resonse to NSDictionary
            
            let data = NSData (contentsOf: requestURL! as URL)
            
            //getting the JSON array teams from the response
            // let teams: NSArray = teamJSON["teams"] as! NSArray
            self.values = try! JSONSerialization.jsonObject(with: data! as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSArray
            
            print("=================== before loop \(self.values.count)")
            //looping through all the json objects in the array teams
            for i in 0 ..< self.values.count{
                
                //getting the data at each index
                self.rcv_username = ((self.values[i] as? [String : String])?["username"])!
                self.rcv_password = ((self.values[i] as? [String : String])?["password"])!
                self.rcv_name = ((self.values[i] as? [String : String])?["name"])!
                self.rcv_is_block = ((self.values[i] as? [String : String])?["is_block"])!
                
                //displaying the data
                print("username -> ", self.rcv_username)
                print("password -> ", self.rcv_password)
                print("name -> ", self.rcv_name)
                print("is_block -> ", self.rcv_is_block)
                
                print("===================")
                print("")
                
            }
        }
        //executing the task
        task.resume()

    }
    
    
}
