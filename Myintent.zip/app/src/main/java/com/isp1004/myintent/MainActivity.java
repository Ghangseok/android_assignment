package com.isp1004.myintent;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    EditText editPassword;
    TextView txtMessage;

    TimerTask task;
    Timer timer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = (EditText)findViewById(R.id.editName);
        editPassword = (EditText)findViewById(R.id.editPassword);
        txtMessage = (TextView)findViewById(R.id.txtMessage);

        task = new TimerTask() {
            @Override
            public void run() {
                txtMessage.post(new Runnable() {
                    @Override
                    public void run() {
                        txtMessage.setText("Time : " + System.currentTimeMillis());
                    }
                });
            };
        };
        timer = new Timer();

    }

    public void onLogin(View view) {
        String strName = editName.getText().toString();
        String strPassword = editPassword.getText().toString();

        txtMessage.setText("Name is " + strName + " and Password is " + strPassword);

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.putExtra("name", strName);
        intent.putExtra("password", strPassword);
        startActivity(intent);
    }

    public void onStartTimer(View view) {
        timer.schedule(task, 0, 100);
    }

    public void onStopTimer(View view) {
        timer.cancel();
    }

    public void onGetData(View view) {

        // AsycTask Example
        MyTask myTask = new MyTask(MainActivity.this, txtMessage);
        myTask.execute();

    }

    class MyTask extends AsyncTask<Void, String, String> {

        private Context context;
        private TextView textView;

        private ProgressDialog progressDialog;

        public MyTask(Context context, TextView textView) {
            this.context = context;
            this.textView = textView;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //super.onPreExecute();
            this.progressDialog = new ProgressDialog(this.context);
            this.progressDialog.setTitle("Downloading File");
            this.progressDialog.setMax(10);
            this.progressDialog.setProgress(0);
            this.progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            this.progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            int i = 0;
            synchronized (this) {
                while (i < 10) {
                    try {
                        this.wait(1000);
                        i++;
                        publishProgress(String.valueOf(i));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            return "Download Complete";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            this.progressDialog.setMessage("Downloaded");
            this.textView.setText("Downloaded");
            this.progressDialog.hide();
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);

            this.progressDialog.setProgress(Integer.parseInt(values[0]));
            this.progressDialog.setMessage("Downloading");
            this.textView.setText("Downloading");
        }
    }
}
