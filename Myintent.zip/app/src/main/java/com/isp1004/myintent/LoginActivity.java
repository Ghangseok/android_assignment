package com.isp1004.myintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    TextView txtMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtMessage = (TextView)findViewById(R.id.textLoginMessage);

        Intent intent = getIntent();
        String strName = intent.getStringExtra("name");
        String strPassword = intent.getStringExtra("password");

        txtMessage.setText(strName + ":" + strPassword);

    }
}
