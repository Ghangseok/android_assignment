package com.isp1004.assignmentmar30daniel;

/**
 * Created by Administrator on 2017-03-29.
 */

public class StudentContact {

    public static abstract class DBList {
                                      //KEY           Column Name
        public static final String TABLE_NAME = "Students";

        public static final String STUDENT_NAME = "name";
        public static final String STUDENT_ID   = "id";
        public static final String STUDENT_AGE  = "age";
    }
}
