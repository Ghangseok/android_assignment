package com.isp1004.assignmentmar30daniel;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class StudentInfoActivity extends AppCompatActivity {

    EditText edtStudentId;
    EditText edtStudentName;
    EditText edtStudentAge;
    Button btnAction;

    int iStudentId;
    String strStudentName;
    int iStudentAge;

    String strType;

    DatabaseHelper databaseHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_info);

        edtStudentId = (EditText)findViewById(R.id.edt_student_id);
        edtStudentName = (EditText)findViewById(R.id.edt_student_name);
        edtStudentAge = (EditText)findViewById(R.id.edt_student_age);

        btnAction = (Button)findViewById(R.id.btn_action);

        edtStudentId.setEnabled(false);

        Intent intent = this.getIntent();
        strType = intent.getStringExtra("type");

        if (strType.intern() == "add") {
            btnAction.setText("Add");
        } else {
            iStudentId = intent.getIntExtra("id", 0);
            strStudentName = intent.getStringExtra("name");
            iStudentAge = intent.getIntExtra("age", 0);
            edtStudentId.setText(String.valueOf(iStudentId));
            edtStudentName.setText(strStudentName);
            edtStudentAge.setText(String.valueOf(iStudentAge));
            btnAction.setText("Update");
        }

        databaseHelper = new DatabaseHelper(getApplicationContext());
    }

    public void onAction(View view) {
        sqLiteDatabase = databaseHelper.getWritableDatabase();

        String strStudentId = edtStudentId.getText().toString();
        String strStudentName = edtStudentName.getText().toString();
        String strStudentAge = edtStudentAge.getText().toString();

        if (strType.intern() == "add") {
            databaseHelper.addStudent(strStudentName, strStudentAge, sqLiteDatabase);
        } else {
            databaseHelper.updateStudent(strStudentId, strStudentName, strStudentAge, sqLiteDatabase);
        }

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
