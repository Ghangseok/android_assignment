package com.isp1004.assignmentmar30daniel;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017-03-29.
 */

public class StudentListAdaptor extends ArrayAdapter {

    List list = new ArrayList();

    public StudentListAdaptor(@NonNull Context context, @LayoutRes int resource) {
        super(context, resource);
    }

    static class LayoutHandler {
        TextView ID, NAME, AGE;
    }

    @Override
    public void add(@Nullable Object object) {
        super.add(object);
        list.add(object);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View row = convertView;
        LayoutHandler layoutHandler;
        if (row == null)
        {
            LayoutInflater layoutInflater = (LayoutInflater)this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = layoutInflater.inflate(R.layout.student_layout,parent,false);
            layoutHandler = new LayoutHandler();
            layoutHandler.ID = (TextView) row.findViewById(R.id.txt_student_id);
            layoutHandler.NAME = (TextView) row.findViewById(R.id.txt_student_name);
            layoutHandler.AGE = (TextView) row.findViewById(R.id.txt_student_age);

            row.setTag(layoutHandler);

        } else {
            layoutHandler = (LayoutHandler) row.getTag();
        }

        StudentVO studentVO = (StudentVO) this.getItem(position);
        layoutHandler.ID.setText(String.valueOf(studentVO.getId()));
        layoutHandler.NAME.setText(studentVO.getName());
        layoutHandler.AGE.setText(String.valueOf(studentVO.getAge()));

        return row;
    }

    public void listClear() {
        list.clear();
    }

}
