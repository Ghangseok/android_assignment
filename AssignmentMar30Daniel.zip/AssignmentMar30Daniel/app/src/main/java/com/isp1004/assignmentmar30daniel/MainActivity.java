package com.isp1004.assignmentmar30daniel;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    Context context = this;

    ListView lvStudentList;

    SQLiteDatabase sqLiteDatabase;
    DatabaseHelper databaseHelper;

    Cursor cursor;

    StudentListAdaptor studentListAdaptor;

    EditText edtSearch;

    int positionOflvStudentList = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtSearch = (EditText)findViewById(R.id.edt_search_value);

        lvStudentList = (ListView) findViewById(R.id.lv_student_list);
        studentListAdaptor = new StudentListAdaptor(getApplicationContext(), R.layout.student_layout);
        lvStudentList.setAdapter(studentListAdaptor);
        lvStudentList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Activity Operations", "item click position : " + position);
                positionOflvStudentList = position;
            }
        });

        databaseHelper = new DatabaseHelper(context);
        sqLiteDatabase = databaseHelper.getReadableDatabase();

        // Get the data
        cursor = databaseHelper.queryStudents(sqLiteDatabase);

        drawStudentList(cursor);
    }


    public void onStudentAdd(View view) {
        Intent intent = new Intent(this, StudentInfoActivity.class);
        intent.putExtra("type", "add");
        startActivity(intent);
    }

    public void onStudentUpdate(View view) {
        Log.d("Activity Operations", String.valueOf(positionOflvStudentList));
        Log.d("Activity Operations", ((StudentVO)lvStudentList.getItemAtPosition(positionOflvStudentList)).toString());

        StudentVO studentVO = (StudentVO)lvStudentList.getItemAtPosition(positionOflvStudentList);

        Intent intent = new Intent(this, StudentInfoActivity.class);
        intent.putExtra("type", "update");
        intent.putExtra("id", studentVO.getId());
        intent.putExtra("name", studentVO.getName());
        intent.putExtra("age", studentVO.getAge());
        startActivity(intent);

    }

    public void onStudentDelete(View view) {
        StudentVO studentVO = (StudentVO)lvStudentList.getItemAtPosition(positionOflvStudentList);

        databaseHelper.deleteStudent(String.valueOf(studentVO.getId()), databaseHelper.getWritableDatabase());

        sqLiteDatabase = databaseHelper.getReadableDatabase();

        // Redraw student list
        cursor = databaseHelper.queryStudents(sqLiteDatabase);
        drawStudentList(cursor);

    }

    public void onStudentSearch(View view) {
        RadioGroup radioTypeGroup = (RadioGroup)findViewById(R.id.radio_type_group);
        RadioButton radioType = (RadioButton)findViewById(radioTypeGroup.getCheckedRadioButtonId());
        String searchValue = edtSearch.getText().toString();
        Log.d("Activity Operations", "search value : " + searchValue);

        sqLiteDatabase = databaseHelper.getReadableDatabase();

        if (radioType.getText().toString().intern() == "NAME") {
            cursor = databaseHelper.searchStudentWithName(searchValue, sqLiteDatabase);
        } else {
            cursor = databaseHelper.searchStudentWithAge(searchValue, sqLiteDatabase);
        }

        drawStudentList(cursor);
    }

    private void drawStudentList(Cursor cursor) {
        studentListAdaptor.listClear();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int age = cursor.getInt(2);

                StudentVO studentVO = new StudentVO(id, name, age);
                Log.d("Activity Operations", studentVO.toString());
                studentListAdaptor.add(studentVO);
            } while (cursor.moveToNext());
        }
    }
}
