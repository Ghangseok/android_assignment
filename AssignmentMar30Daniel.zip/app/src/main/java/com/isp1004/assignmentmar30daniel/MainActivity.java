package com.isp1004.assignmentmar30daniel;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    Context context = this;

    ListView lvStudentList;

    SQLiteDatabase sqLiteDatabase;
    DatabaseHelper databaseHelper;

    Cursor cursor;

    StudentListAdaptor studentListAdaptor;

    EditText edtSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtSearch = (EditText)findViewById(R.id.edt_search_value);

        lvStudentList = (ListView) findViewById(R.id.lv_student_list);
        studentListAdaptor = new StudentListAdaptor(getApplicationContext(), R.layout.student_layout);
        lvStudentList.setAdapter(studentListAdaptor);

        databaseHelper = new DatabaseHelper(context);
        sqLiteDatabase = databaseHelper.getReadableDatabase();

        // Get the data
        cursor = databaseHelper.queryStudents(sqLiteDatabase);

        drawStudentList(cursor);
    }


    public void onStudentAdd(View view) {
        Intent intent = new Intent(this, StudentInfoActivity.class);
        intent.putExtra("type", "add");
        startActivity(intent);
    }

    public void onStudentUpdate(View view) {
        StudentVO studentVO = (StudentVO)lvStudentList.getSelectedItem();

        Intent intent = new Intent(this, StudentInfoActivity.class);
        intent.putExtra("type", "update");
        intent.putExtra("id", studentVO.getId());
        intent.putExtra("name", studentVO.getName());
        intent.putExtra("age", studentVO.getAge());
        startActivity(intent);
    }

    public void onStudentDelete(View view) {
        StudentVO studentVO = (StudentVO)lvStudentList.getSelectedItem();

        databaseHelper.deleteStudent(String.valueOf(studentVO.getId()), databaseHelper.getWritableDatabase());

    }

    public void onStudentSearch(View view) {
        RadioGroup radioTypeGroup = (RadioGroup)findViewById(R.id.radio_type_group);
        RadioButton radioType = (RadioButton)findViewById(radioTypeGroup.getCheckedRadioButtonId());
        String searchValue = edtSearch.getText().toString();

        sqLiteDatabase = databaseHelper.getReadableDatabase();

        if (radioType.getText().toString().intern() == "NAME") {
            cursor = databaseHelper.searchStudentWithName(searchValue, sqLiteDatabase);
        } else {
            cursor = databaseHelper.searchStudentWithAge(searchValue, sqLiteDatabase);
        }

        drawStudentList(cursor);
    }

    private void drawStudentList(Cursor cursor) {
        studentListAdaptor.listClear();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int age = cursor.getInt(2);

                StudentVO studentVO = new StudentVO(id, name, age);
                studentListAdaptor.add(studentVO);
            } while (cursor.moveToNext());
        }
    }
}
