package com.isp1004.assignmentmar30daniel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Administrator on 2017-03-29.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "DataBaseTwo";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_QUERY =
            "CREATE TABLE " +
                    StudentContact.DBList.TABLE_NAME      +   " ("        +
                    StudentContact.DBList.STUDENT_ID      +   " INTEGER PRIMARY KEY, "   +
                    StudentContact.DBList.STUDENT_NAME    +   " TEXT, "   +
                    StudentContact.DBList.STUDENT_AGE     +   " INTEGER);"   ;


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("DB Operations", "Database Created / Opened");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QUERY);
        Log.d("DB Operations", "Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // Add student
    public void addStudent(String name, String age, SQLiteDatabase db) {
        ContentValues contentValues = new ContentValues();

        int id = (int) (System.currentTimeMillis());

        contentValues.put(StudentContact.DBList.STUDENT_ID, id);
        contentValues.put(StudentContact.DBList.STUDENT_NAME, name);
        contentValues.put(StudentContact.DBList.STUDENT_AGE, Integer.parseInt(age));

        db.insert(StudentContact.DBList.TABLE_NAME, null, contentValues);
        Log.d("DB Operations", "Student Added");

    }

    // update student
    public void updateStudent(String id, String name, String age, SQLiteDatabase db) {
        ContentValues contentValues = new ContentValues();

        contentValues.put(StudentContact.DBList.STUDENT_NAME, name);
        contentValues.put(StudentContact.DBList.STUDENT_AGE, Integer.parseInt(age));

        String selection = StudentContact.DBList.STUDENT_ID + " = ?";
        String[] selection_args = { id };

        db.update(StudentContact.DBList.TABLE_NAME, contentValues, selection, selection_args);
        Log.d("DB Operations", "Student Update");

    }

    // delete student
    public void deleteStudent(String id, SQLiteDatabase db) {
        String selection = StudentContact.DBList.STUDENT_ID + " = ?";
        String[] selection_args = { id };

        db.delete(StudentContact.DBList.TABLE_NAME, selection, selection_args);
        Log.d("DB Operations", "Student Delete");
    }

    // query student list
    public Cursor queryStudents(SQLiteDatabase db) {
        Cursor cursor;
        String[] projecttions = { StudentContact.DBList.STUDENT_ID, StudentContact.DBList.STUDENT_NAME, StudentContact.DBList.STUDENT_AGE};
        cursor = db.query(StudentContact.DBList.TABLE_NAME, projecttions, null, null, null, null, null);

        Log.d("DB Operations", "Qeury Students");

        return cursor;
    }

    // search student with name
    public Cursor searchStudentWithName(String name, SQLiteDatabase db) {
        Cursor cursor;
        String[] projecttions = { StudentContact.DBList.STUDENT_ID, StudentContact.DBList.STUDENT_NAME, StudentContact.DBList.STUDENT_AGE};
        String selection = StudentContact.DBList.STUDENT_NAME + " like ?";
        String[] selection_args = { name };

        cursor = db.query(StudentContact.DBList.TABLE_NAME, projecttions, selection, selection_args, null, null, null);

        Log.d("DB Operations", "Qeury Student with name");

        return cursor;

    }

    // search student with age
    public Cursor searchStudentWithAge(String age, SQLiteDatabase db) {
        Cursor cursor;
        String[] projecttions = { StudentContact.DBList.STUDENT_ID, StudentContact.DBList.STUDENT_NAME, StudentContact.DBList.STUDENT_AGE};
        String selection = StudentContact.DBList.STUDENT_AGE + " = ?";
        String[] selection_args = { age };

        cursor = db.query(StudentContact.DBList.TABLE_NAME, projecttions, selection, selection_args, null, null, null);

        Log.d("DB Operations", "Qeury Student with age");

        return cursor;

    }

}
