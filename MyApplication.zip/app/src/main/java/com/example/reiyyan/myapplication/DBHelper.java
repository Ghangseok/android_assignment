package com.example.reiyyan.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "DataBaseOne";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_QUERY =
                "CREATE TABLE " +
                UserContract.DBList.TABLE_NAME      +   " ("        +
                UserContract.DBList.USER_NAME       +   " TEXT, "   +
                UserContract.DBList.USER_NUMBER     +   " TEXT);"   ;


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.e("DB Operations", "Database Created / Opened");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_QUERY);
        Log.e("DB Operations", "Table Created");
    }

    //ADD INFORMATION SECTIONS

    public void addInformation(String name, String number, SQLiteDatabase db)
    {
        ContentValues contentValues = new ContentValues();

        contentValues.put(UserContract.DBList.USER_NAME, name);
        contentValues.put(UserContract.DBList.USER_NUMBER, number);

        db.insert(UserContract.DBList.TABLE_NAME, null, contentValues);

        Log.e("DB Operations", "Row Added");
    }



    //FIND INFORMATION SECTION
    public Cursor getInformation(SQLiteDatabase db)
    {
        Cursor cursor;
        String[] projections = {UserContract.DBList.USER_NAME, UserContract.DBList.USER_NUMBER};

        cursor = db.query(UserContract.DBList.TABLE_NAME, projections, null, null, null, null, null);

        return cursor;
    }


    //SEARCH SECTION

    public Cursor getContact(String user_name, SQLiteDatabase sqLiteDatabase)
    {
        String[] projections = {UserContract.DBList.USER_NUMBER};
        String selection = UserContract.DBList.USER_NAME + " LIKE ?";
        String[] selection_args = {user_name};

        Cursor cursor = sqLiteDatabase.query(UserContract.DBList.TABLE_NAME, projections, selection, selection_args, null, null, null);
        return cursor;

    }


    //DELETION SECTION
    public void deleteInformation(String user_name, SQLiteDatabase sqLiteDatabase)
    {
        String selection = UserContract.DBList.USER_NAME + " LIKE ?";
        String[] selection_args = {user_name};
        sqLiteDatabase.delete(UserContract.DBList.TABLE_NAME, selection, selection_args);
    }


    //UPDATE SECTION

    public int updateInformation(String old_name, String new_name, String new_number, SQLiteDatabase sqLiteDatabase)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(UserContract.DBList.USER_NAME, new_name);
        contentValues.put(UserContract.DBList.USER_NUMBER, new_number);

        String selection = UserContract.DBList.USER_NAME + " LIKE ?";
        String[] selection_args = {old_name};

        int count = sqLiteDatabase.update(UserContract.DBList.TABLE_NAME, contentValues, selection, selection_args);

        return count;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
