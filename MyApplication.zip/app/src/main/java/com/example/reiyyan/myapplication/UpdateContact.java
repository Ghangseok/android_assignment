package com.example.reiyyan.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateContact extends AppCompatActivity {

    EditText searchName, updateName, updateNumber;

    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;

    String search_name;

    String newNumber;
    String newName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contact);

        searchName = (EditText) findViewById(R.id.searchName);
        updateName = (EditText) findViewById(R.id.updateName);
        updateNumber = (EditText) findViewById(R.id.updateNumber);


    }


    public void onSearch(View v)
    {
        search_name = searchName.getText().toString();

        dbHelper = new DBHelper(getApplicationContext());
        sqLiteDatabase = dbHelper.getReadableDatabase();

        Cursor cursor = dbHelper.getContact(search_name, sqLiteDatabase);

        if (cursor.moveToFirst())
        {
            newNumber = cursor.getString(0);
            newName = search_name;

            updateName.setText(newName);
            updateNumber.setText(newNumber);

        }
    }

    public void onUpdate(View v)
    {
        dbHelper = new DBHelper(getApplicationContext());
        sqLiteDatabase = dbHelper.getWritableDatabase();

        String name, number;

        name = updateName.getText().toString();
        number = updateNumber.getText().toString();

        int count = dbHelper.updateInformation(search_name, name, number, sqLiteDatabase);

        Toast.makeText(this,"Contact Updated", Toast.LENGTH_LONG).show();
        finish();
    }
}
