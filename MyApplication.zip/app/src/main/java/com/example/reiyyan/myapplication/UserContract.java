package com.example.reiyyan.myapplication;


public class UserContract {

    public static abstract class DBList

    {                               //KEY           Column Name
        public static final String TABLE_NAME = "FirstTable";

        public static final String USER_NAME = "Name";
        public static final String USER_NUMBER = "Number";

    }

}
