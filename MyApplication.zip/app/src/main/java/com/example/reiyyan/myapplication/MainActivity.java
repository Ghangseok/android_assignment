package com.example.reiyyan.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToAdd(View v)
    {
        Intent intent;
        intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    public void goToView(View v)
    {
        Intent intent;
        intent = new Intent(this, DataListActivity.class);
        startActivity(intent);

    }

    public void goToSearch(View v)
    {
        Intent intent;
        intent = new Intent(this, SearchContact.class);
        startActivity(intent);
    }

    public void goToUpdate(View v)
    {
        Intent intent;
        intent = new Intent(this, UpdateContact.class);
        startActivity(intent);
    }
}
