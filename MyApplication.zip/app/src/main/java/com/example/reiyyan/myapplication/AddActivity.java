package com.example.reiyyan.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {

    EditText Name, Number;

    Context context = this;
    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Name = (EditText) findViewById(R.id.editText);
        Number = (EditText) findViewById(R.id.editText2);

    }

    public void AddRow(View v)
    {
        String name = Name.getText().toString();
        String number = Number.getText().toString();

        dbHelper = new DBHelper(context);

        sqLiteDatabase = dbHelper.getWritableDatabase();

        dbHelper.addInformation(name, number, sqLiteDatabase);

        Toast.makeText(context, "ONE ROW IS ADDED", Toast.LENGTH_LONG).show();

        dbHelper.close();
    }
}
