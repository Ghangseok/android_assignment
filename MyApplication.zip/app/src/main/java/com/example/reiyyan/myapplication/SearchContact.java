package com.example.reiyyan.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SearchContact extends AppCompatActivity {

    TextView displayNumber;
    EditText sEditName;

    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;
    String search_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_contact);

        displayNumber = (TextView) findViewById(R.id.display_mobile);
        sEditName = (EditText) findViewById(R.id.searchName);
    }

    public void onSearch(View v)
    {
        search_name = sEditName.getText().toString();

        dbHelper = new DBHelper(getApplicationContext());
        sqLiteDatabase = dbHelper.getReadableDatabase();

        Cursor cursor = dbHelper.getContact(search_name, sqLiteDatabase);

        if (cursor.moveToFirst())
        {
            String MOBILE = cursor.getString(0);
            displayNumber.setText(MOBILE);
        }
    }

    public void onDelete(View v)
    {
        dbHelper = new DBHelper(getApplicationContext());
        sqLiteDatabase = dbHelper.getReadableDatabase();

        dbHelper.deleteInformation(search_name, sqLiteDatabase);

        Toast.makeText(this, "Contact Deleted", Toast.LENGTH_LONG).show();
    }
}
