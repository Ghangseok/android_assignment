package com.example.reiyyan.myapplication;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class DataListActivity extends AppCompatActivity {

    ListView listView;

    SQLiteDatabase sqLiteDatabase;
    DBHelper dbHelper;

    Cursor cursor;

    ListDataAdapter listDataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_list);

        listView = (ListView) findViewById(R.id.list_view);
        listDataAdapter = new ListDataAdapter(getApplicationContext(), R.layout.row_layout);

        listView.setAdapter(listDataAdapter);


        dbHelper = new DBHelper(getApplicationContext());
        sqLiteDatabase = dbHelper.getReadableDatabase();

        //Get the Data
        cursor = dbHelper.getInformation(sqLiteDatabase);

        if(cursor.moveToFirst())
        {
            do {
                String name, number;

                //Get information
                name = cursor.getString(0);
                number = cursor.getString(1);

                DataProvider dataProvider = new DataProvider(name, number);

                listDataAdapter.add(dataProvider);

            } while (cursor.moveToNext());


        }

    }
}
